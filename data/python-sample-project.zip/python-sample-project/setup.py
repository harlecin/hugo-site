from setuptools import setup
from setuptools import find_packages

setup(name='<pkg-name>',
      version='0.10',
      description='<package-description-here>',
      author='<your-name>',
      author_email='<your-email>',
      license='<your-license>',
      packages=find_packages("src"),
      package_dir={"": "src"},
      zip_safe=False,
      install_requires=[
          '<some-pkg>,
          ## Note: the space between the @ are acutally necessary!
          '<some-gitlab-package>  @  git+ssh://git@<package-url-with-slashes>.git@master',
      ],
      extras_require={
          'dev': [
              'pytest',
              'mypy',
              'pylint',
              'coverage',
              'python-dotenv',
              'tox-conda',
              'ipykernel',
              'matplotlib',
              'plotnine',
              'seaborn',
          ]
      }
)