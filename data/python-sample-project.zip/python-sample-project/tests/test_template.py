import pkg_name as pkg
import pytest

def test():
    pytest.fail('todo') 